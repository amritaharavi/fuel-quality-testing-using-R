
library(dplyr)          
library(ggplot2)
library(tidyr)
library(corrplot)
library(ggpubr)         
library(DataExplorer)   

# Load dataset
data(mtcars)

#  the first few rows of  dataset
head(mtcars)

# Check for missing values
sum(is.na(mtcars))

# Summary statistics
summary(mtcars)

# Checking data types
str(mtcars)

#  DataExplorer
DataExplorer::introduce(mtcars)  # Using explicit namespace
DataExplorer::plot_intro(mtcars)
DataExplorer::plot_missing(mtcars)

# Pair plot using DataExplorer
DataExplorer::plot_correlation(mtcars, type = "continuous", title = "Correlation Matrix")

# Data normalization for regression model
mtcars_normalized <- as.data.frame(scale(mtcars))
head(mtcars_normalized)

# Data Visualization
# Scatter plot: mpg vs. wt (weight)
ggplot(mtcars, aes(x = wt, y = mpg)) +
  geom_point(color = "blue", size = 3, alpha = 0.7) +
  labs(title = "Miles per Gallon vs. Weight", x = "Weight (1000 lbs)", y = "Miles per Gallon") +
  theme_minimal()


# Density plot for mpg
ggplot(mtcars, aes(x = mpg, fill = "Density")) +
  geom_density(alpha = 0.7) +
  labs(title = "Density Plot of Miles per Gallon", x = "Miles per Gallon", y = "Density") +
  theme_minimal()

# Correlation Matrix of Numeric Variables
corr_matrix <- cor(mtcars)
corrplot(corr_matrix, method = "circle", type = "upper", tl.col = "black", tl.srt = 45)

# Bar plot for categorical visualization (cylinders)
ggplot(mtcars, aes(x = factor(cyl))) +
  geom_bar(fill = "skyblue") +
  labs(title = "Distribution of Cylinders", x = "Cylinders", y = "Count") +
  theme_minimal()

# Correlation between mpg and other variables
cor(mtcars$mpg, mtcars$hp)  # mpg vs horsepower
cor(mtcars$mpg, mtcars$wt)  # mpg vs weight

# Linear Regression Model to predict mpg
model <- lm(mpg ~ wt + hp + qsec + drat, data = mtcars)

# View model summary
summary(model)

# Predict mpg for new data (example)
new_data <- data.frame(wt = 3, hp = 100, qsec = 18, drat = 3.9)
predicted_mpg <- predict(model, new_data)
predicted_mpg

